import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
import pickle

# Generate synthetic data (you can replace this with real data)
np.random.seed(42)
data_size = 1000

temperature = np.random.uniform(18, 30, size=data_size)  # Temperature in °C
humidity = np.random.uniform(30, 80, size=data_size)  # Humidity in %
hour = np.random.randint(0, 24, size=data_size)  # Hour of the day (0–23)
day = np.random.randint(0, 7, size=data_size)  # Day of the week (0–6)

# Random energy consumption data (target variable in kWh)
energy_consumption = temperature * 0.5 + humidity * 0.2 + hour * 0.3 + day * 0.1 + np.random.normal(0, 5, data_size)

# Create a DataFrame
df = pd.DataFrame({
    'temperature': temperature,
    'humidity': humidity,
    'hour': hour,
    'day': day,
    'energy_consumption': energy_consumption
})

# Features and target
X = df[['temperature', 'humidity', 'hour', 'day']]
y = df['energy_consumption']

# Train the Random Forest model
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X, y)

# Save the model to a file
with open('model.pkl', 'wb') as model_file:
    pickle.dump(model, model_file)

print("Model trained and saved successfully!")
