from flask import Flask, request, jsonify
from flask_cors import CORS
import pickle

app = Flask(__name__)
CORS(app)

# Load the trained model from the pickle file
with open('model.pkl', 'rb') as model_file:
    model = pickle.load(model_file)

@app.route('/')
def home():
    return "Energy Consumption Prediction API is running!"

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get the data from the POST request
        data = request.get_json()

        # Extract features from the request data
        temperature = data.get('temperature')
        humidity = data.get('humidity')
        hour = data.get('hour')
        day = data.get('day')

        # Check if all required data is provided
        if not all([temperature, humidity, hour, day]):
            return jsonify({"error": "Missing data, please provide all input values"}), 400

        # Prepare the input data for prediction
        input_data = [[temperature, humidity, hour, day]]

        # Make the prediction
        prediction = model.predict(input_data)

        # Return the prediction as a JSON response
        return jsonify({"predicted_energy_consumption": float(prediction[0])}), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
